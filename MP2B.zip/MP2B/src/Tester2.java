
public class Tester2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Class2 test = new Class2(11);
		
		test.load();
		
		test.search(20);
		
		test.findMax();
		
		test.findMin();
		
		test.findMaxPos();
		
		test.findMinPos();
		
		

	}

}
