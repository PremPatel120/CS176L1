
public class Tester1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Class1 test = new Class1(5);
		
		test.load();
		
		test.search1("prem");
		
		test.findMax();
		
		test.findMin();
		
		test.findLongest();
		
		test.findShortest();
		
		//System.out.println(test.search1("prem"));
		
		//System.out.println(test.findMax());
		

	}

}
